package view;

import controller.GameController;
import model.ResultChecker;
import model.ResultSaver;
import model.QuestionList;
import model.QuestionDBManager;
import model.Question;
import model.nonCelebContester;
import model.CelebrityContester;
import model.Contester;
import model.Chance;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.List;
import java.util.ArrayList;


public class QuizGameGUI 
{
  
    public JFrame frame;
    private JButton startButton;
    private JButton[] answerButtons;
    private JTextField playerNameField;
    private JTextArea questionTextArea;
    private JCheckBox celebrityCheckBox;
    private JLabel feedbackLabel;
    private JButton closeButton;
    private JButton restartButton;
    private JButton chanceButton;
    private JLabel prizeLabel;
    private JLabel stageLabel;


    private QuestionList questionList;
    private Question currentQuestion;
    public Contester player;
    private ResultSaver resultSaver;

    public static int stage;     
    public static int stage2;     

    private Font font;
    private GameController gameController;

    
    final static int[] prize = {100,200,300,500,1000,2000,4000,8000,16000,32000,64000,125000,250000,500000,1000000};
    private Chance gameChance;

    /**
     * This is a constructor for QuizGameGUI. 
     * @param dbManager which is to connect to the database.
     * @throws IOException if there is an input exception.
     */    
    public QuizGameGUI(QuestionDBManager dbManager) throws IOException 
    {
        questionList = new QuestionList(dbManager);
        resultSaver = new ResultSaver(dbManager);
        
        this.gameController = new GameController(this, resultSaver);

        
        frame = new JFrame("Quiz Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1450, 950);
        
        playerNameField = new JTextField(25);
        celebrityCheckBox = new JCheckBox("I'm a celebrity");

        font = new Font("Arial", Font.BOLD, 23);
        playerNameField.setFont(font);



        playerNameField.setPreferredSize(new Dimension(300, 40));

        JScrollPane scrollPane = new JScrollPane(questionTextArea);
        scrollPane.setPreferredSize(new Dimension(300, 200));
        frame.add(scrollPane, BorderLayout.CENTER);

        
        gameChance = new Chance();
        
        startButton = new JButton("Start Game");
        startButton.setFont(font);

        startButton.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                try 
                {
                    startGame();
                } catch (IOException ex) 
                {
                    Logger.getLogger(QuizGameGUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        closeButton = new JButton("Close");
        closeButton.setFont(font);
        
        closeButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) 
            {
                frame.dispose();
            }
        });

        restartButton = new JButton("Restart Game");
        restartButton.setFont(font);

        restartButton.addActionListener(new ActionListener() 
        {

            public void actionPerformed(ActionEvent e) 
            {            
                frame.dispose();

                try 
                {
                    QuestionDBManager newDbManager = new QuestionDBManager();
                    QuizGameGUI newGameGUI = new QuizGameGUI(newDbManager);
                    newGameGUI.frame.setVisible(true);
                } 
                catch (IOException ex) 
                {
                    Logger.getLogger(QuizGameGUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        chanceButton = new JButton("Use Chance");
        chanceButton.setFont(font);
        
        chanceButton.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                useChance();
            }
        });
        
        Font fontTextArea = new Font("Arial", Font.PLAIN, 20);    
        questionTextArea = new JTextArea(10, 25);
        questionTextArea.setEditable(false);
        questionTextArea.setFont(fontTextArea);         
        questionTextArea.setText
        (
            "Answer 15 questions and win ONE MILLION DOLLARS!\n" +
            "Contesters will lose everything if doesn't get the right answer at any stage of the game.\n" +
            "Contesters can walk away with the prize at any stage of the game.\n" +
            "Chance: Eliminates two incorrect answers, providing a 50/50 chance of selecting the correct answer!\n\n" +
            "Type your name in the text field above and click the Start button. If you are a celebrity, please click the check box before clicking the Start button\n\n" +
            "You only can play once!!"
    
        );

        answerButtons = new JButton[4];
        for (int i = 0; i < 4; i++) 
        {
            answerButtons[i] = new JButton();
            answerButtons[i].setEnabled(false);
            final int index = i;
            answerButtons[i].addActionListener(new ActionListener() 
            {
                public void actionPerformed(ActionEvent e) 
                {
                    try 
                    {
                        handleAnswer(index);
                    } 
                    catch (IOException ex) 
                    {
                        Logger.getLogger(QuizGameGUI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
        }

        for (JButton button : answerButtons) {
       button.setFont(font);
       }       
        
        
        feedbackLabel = new JLabel();
        feedbackLabel.setFont(font);

        frame.setLayout(new BorderLayout());
        JPanel topPanel = new JPanel();
        topPanel.add(playerNameField);
        topPanel.add(celebrityCheckBox);
        topPanel.add(startButton);
        topPanel.add(closeButton);
        topPanel.add(restartButton);
        topPanel.add(chanceButton);

        
        frame.add(topPanel, BorderLayout.NORTH);

        frame.add(new JScrollPane(questionTextArea), BorderLayout.CENTER);

        prizeLabel = new JLabel("Current Prize: $0");
        prizeLabel.setFont(font);
       
        stageLabel = new JLabel("Current Stage: 0");
        stageLabel.setFont(font);

        
        JPanel bottomPanel = new JPanel();
        for (JButton button : answerButtons) 
        {
            bottomPanel.add(button);
        }
        bottomPanel.add(feedbackLabel);
        bottomPanel.add(prizeLabel);  
        bottomPanel.add(stageLabel);

        frame.add(bottomPanel, BorderLayout.SOUTH);
        
        celebrityCheckBox.setFont(font);
        frame.setLocationRelativeTo(null);
        
    }
    
    /**
     * This is to start the quiz game.
     * @throws IOException if there is an input exception.
     */
    private void startGame() throws IOException 
    {
        startButton.setEnabled(false);
        celebrityCheckBox.setEnabled(false);
        stage2 = stage+1;
        stageLabel.setText("Current Stage: " + stage2); 
        
        for (JButton button : answerButtons) 
        {
            button.setEnabled(true);
        }

        String playerName = playerNameField.getText();
        if (ResultChecker.isTheContesterInResultsFile(playerName)) 
        {
            int prize = ResultChecker.getTheContesterPrize(playerName);

            JOptionPane.showMessageDialog(frame, "You've already contested and won $" + prize, "Already Played", JOptionPane.INFORMATION_MESSAGE);
         
            frame.dispose();

            questionList.getDbManager().closeConnections();
            System.exit(0);
        } 
        else 
        {
            QuestionDBManager dbManager = new QuestionDBManager();
            if (celebrityCheckBox.isSelected()) 
            {
                player = new CelebrityContester(playerName, dbManager);
            } 
            else 
            {
                player = new nonCelebContester(playerName);
            }

            stage = 0;

            nextQuestion();
        }
        
        
        questionTextArea.setFont(font);
       
    }

    /**
     * This is to handle the user's answer.
     * @param buttonIndex which is the index of the button that the user selects.
     * @throws IOException if there is an input exception.
     */
    private void handleAnswer(int buttonIndex) throws IOException 
    {
        String chosenAnswer = answerButtons[buttonIndex].getText();
        
        if (chosenAnswer.equals(currentQuestion.getRightAnswer())) 
        {
            
            player.setPrize(prize[stage]);
            
            prizeLabel.setText("Current Prize: $" + player.getPrize()); 
            stage++;
            stage2 = stage + 1;
            
            if(stage <= 15)
            {
                 stageLabel.setText("Current Stage: " + stage2); 
            }
            else
            {
                 stageLabel.setText("Complete!"); 

            }
            stage2++;
           
            int choice = JOptionPane.showConfirmDialog(frame,
                    "You got it right! Your prize is now $" + player.getPrize() + ". Do you want to walk away?", "Correct Answer",
                    JOptionPane.YES_NO_OPTION);

            if (choice == JOptionPane.YES_OPTION) 
            {             
                String feedback = JOptionPane.showInputDialog(frame, "Please provide your feedback about the game:");
                resultSaver.saveNotCompletedContester(player, feedback);
                gameCompleted();
            } 
            else 
            {
                nextQuestion();
            }
        } 
        else
        {
            player.setPrize(0);
            prizeLabel.setText("Current Prize: $0"); 

            feedbackLabel.setText("Sorry, that's incorrect. The correct answer was: " + currentQuestion.getRightAnswer());
            String feedback = JOptionPane.showInputDialog(frame, "Please provide your feedback about the game:");
            resultSaver.saveNotCompletedContester(player, feedback);
            gameCompleted();
        }
    }

    /**
     * This is to end the game which saves the result.
     * @throws IOException if there is an input exception.
     */
private void gameCompleted() throws IOException {
    gameController.gameCompleted();
}

    /**
     * This is to use the chance which eliminates two incorrect answers.
     */    
    private void useChance() 
    {
        if (gameChance.hasUsedChance) 
        {
            JOptionPane.showMessageDialog(frame, "You've already used your chance!", "No More Chances", JOptionPane.WARNING_MESSAGE);



        } 
        else 
        {
            gameChance.chanceOf5050(player, currentQuestion);
            displayTwoOptions();
            chanceButton.setEnabled(false);

        }
    }

    /**
     * This is to display two options which is one correct answer and one incorrect answer.
     */    
    private void displayTwoOptions() 
    {
        int answerPosition = currentQuestion.getCanbeTrueAnswers().indexOf(currentQuestion.getRightAnswer());
        
        List<Integer> displayedOptions = new ArrayList<>();
        displayedOptions.add(answerPosition);

        for (int i = 0; i < currentQuestion.getCanbeTrueAnswers().size(); i++) 
        {
            if (i != answerPosition && displayedOptions.size() < 2) 
            {
                displayedOptions.add(i);
                break;
            }
        }

        for (int i = 0; i < 4; i++) 
        {
            if (displayedOptions.contains(i))
            {
                answerButtons[i].setEnabled(true);
                answerButtons[i].setText(currentQuestion.getCanbeTrueAnswers().get(i));
            }
            else 
            {
                answerButtons[i].setEnabled(false);
                answerButtons[i].setText("");
            }
        }
    }

    /**
     * This is to move to the next question.
     * @throws IOException if an input or output exception occurs
     */
    private void nextQuestion() throws IOException 
    {
        int currentQuestionIndex = questionList.getAllQuestions().indexOf(currentQuestion);
        
        if (currentQuestionIndex + 1 < questionList.getAllQuestions().size()) {
            currentQuestion = questionList.getAllQuestions().get(currentQuestionIndex + 1);
            questionTextArea.setText(currentQuestion.getQuestion());
            
            for (int i = 0; i < 4; i++) 
            {
                answerButtons[i].setText(currentQuestion.getCanbeTrueAnswers().get(i));
                answerButtons[i].setEnabled(true);
                answerButtons[i].setText(currentQuestion.getCanbeTrueAnswers().get(i));
            }
        }
        else 
        {
            feedbackLabel.setText("Congratulations, you've answered all the questions!");
            String feedback = JOptionPane.showInputDialog(frame, "Please provide your feedback about the game:");
            resultSaver.saveCompletedContester(player, feedback);
            gameCompleted();
            frame.dispose();
        }
    }

    
    
     public JFrame getFrame() {
        return frame;
    }

    public JButton getStartButton() {
        return startButton;
    }

    public JButton[] getAnswerButtons() {
        return answerButtons;
    }

    public JTextField getPlayerNameField() {
        return playerNameField;
    }

    public JTextArea getQuestionTextArea() {
        return questionTextArea;
    }

    public JCheckBox getCelebrityCheckBox() {
        return celebrityCheckBox;
    }

    public JLabel getFeedbackLabel() {
        return feedbackLabel;
    }

    public JButton getCloseButton() {
        return closeButton;
    }

    public JButton getRestartButton() {
        return restartButton;
    }

    public JButton getChanceButton() {
        return chanceButton;
    }

    public JLabel getPrizeLabel() {
        return prizeLabel;
    }

    public JLabel getStageLabel() {
        return stageLabel;
    }

    public void setFrame(JFrame frame) {
        this.frame = frame;
    }

    public void setStartButton(JButton startButton) {
        this.startButton = startButton;
    }

    public void setAnswerButtons(JButton[] answerButtons) {
        this.answerButtons = answerButtons;
    }

    public void setPlayerNameField(JTextField playerNameField) {
        this.playerNameField = playerNameField;
    }

    public void setQuestionTextArea(JTextArea questionTextArea) {
        this.questionTextArea = questionTextArea;
    }

    public void setCelebrityCheckBox(JCheckBox celebrityCheckBox) {
        this.celebrityCheckBox = celebrityCheckBox;
    }

    public void setFeedbackLabel(JLabel feedbackLabel) {
        this.feedbackLabel = feedbackLabel;
    }

    public void setCloseButton(JButton closeButton) {
        this.closeButton = closeButton;
    }

    public void setRestartButton(JButton restartButton) {
        this.restartButton = restartButton;
    }

    public void setChanceButton(JButton chanceButton) {
        this.chanceButton = chanceButton;
    }

    public void setPrizeLabel(JLabel prizeLabel) {
        this.prizeLabel = prizeLabel;
    }

    public void setStageLabel(JLabel stageLabel) {
        this.stageLabel = stageLabel;
    }

    
    
}