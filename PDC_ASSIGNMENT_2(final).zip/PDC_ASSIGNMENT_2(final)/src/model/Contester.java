package model;

import model.Chance;

public abstract class Contester 
{
    private String name;
    private int prize;
    private Chance chance;

    /**
     * This is a Contester's constructor. 
     * @param name is the contester's name.
     */    
    public Contester(String name) 
    {
        this.setName(name);
        this.setPrize(0);
        this.chance = new Chance();
    }

    /**
     * This is to get the name of the contester.
     * @return is the name of the contester.
     */    
    public String getName() 
    {
        return this.name;
    }

    /**
     * This is to set the name of the contester
     * @param newName is the new name of the contester.
     */    
    public void setName(String newName) 
    {
        this.name = newName.toUpperCase();
    }

    /**
     * This is to get the prize of the player. 
     * @return is the amount of the prize.
     */    
    public int getPrize()
    {
        return this.prize;
    }

    /**
     * This is to set the prize.
     * @param prize is the amount of the prize.
     */    
    public void setPrize(int prize) 
    {
        this.prize = prize;
    }
    
    /**
     * This is to get the contester's chance.
     * @return 
     */    
    public Chance getChance()
    {
        return this.chance;
    }
    
    public abstract void displayVictoryMessage();

    
}
