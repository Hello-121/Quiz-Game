package model;

import model.Contester;

public class nonCelebContester extends Contester
{

   /**
    * This is a non-celebrity contester's constructor.
    * @param name 
    */    
   public nonCelebContester(String name) 
   {
        super(name);
   }   

   /**
    * This is to display the victory message.
    */   
    @Override
    public void displayVictoryMessage() 
    {
        System.out.printf(getName() + " has contested as a Non-Celebrity! and ");
    }
}
