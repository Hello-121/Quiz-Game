package model;

import model.QuestionDBManager;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ResultChecker 
{

    private static QuestionDBManager dbManager = new QuestionDBManager();

    /**
     * This method is to check if the player's name is already in the result file.
     * @param contesterName is the name of the player to check if the name is in the file. 
     * @return if the name is in the result file, then true, if not then false.
     * @throws IOException if there is an error when connecting to the database.
     */    
    public static boolean isTheContesterInResultsFile(String contesterName) throws IOException 
    {
        Connection conn = dbManager.getConnection();
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try 
        {
            String query = "SELECT * FROM result WHERE LOWER(name) = LOWER(?)";
            statement = conn.prepareStatement(query);
            statement.setString(1, contesterName);
            resultSet = statement.executeQuery();

            if (resultSet.next()) 
            {

                return true;
            }
        } 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            
        } 
        finally 
        {
            try 
            {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                
            } 
            catch (SQLException ex) 
            {
                System.out.println(ex.getMessage());
                
            }
        }
        
        return false;
    }

     /**
     * This method is to get the player's prize.
     * @param contesterName is the name of the player. 
     * @return is the amount of the prize. 
     * @throws IOException if there is an error when connecting to the database.
     */   
    public static int getTheContesterPrize(String contesterName) throws IOException 
    {
        Connection conn = dbManager.getConnection();
        Statement statement = null;
        ResultSet resultSet = null;
        
        int prize = 0;

        try 
        {
            statement = conn.createStatement();
            resultSet = statement.executeQuery("SELECT MAX(prize) AS max_prize FROM result WHERE name='" + contesterName.toLowerCase() + "'");

            if (resultSet.next()) 
            {
                prize = resultSet.getInt("max_prize");
                
            }
        } 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            
        } 
        finally 
        {
            try 
            {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                
            } 
            catch (SQLException ex) 
            {
                System.out.println(ex.getMessage());
                
            }
        }
        
        try 
        {
            if (conn != null) conn.close();
            
        } 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            
        }

        return prize;
    }

}
