package controller;

import view.QuizGameGUI;
import model.ResultSaver;
import model.CelebrityContester;
import java.io.IOException;

public class GameController {

    private final QuizGameGUI quizGameGUI;
    private final ResultSaver resultSaver;

    /*
     * This is a constructor for GameController.
    */
    public GameController(QuizGameGUI quizGameGUI, ResultSaver resultSaver) {
        this.quizGameGUI = quizGameGUI;
        this.resultSaver = resultSaver;
    }

    /**
     * This is to end the game which saves the result.
     * @throws IOException if there is an input exception.
     */
    public void gameCompleted() throws IOException {
        resultSaver.saveContesterResult(quizGameGUI.player);

        if (quizGameGUI.player instanceof CelebrityContester) {
            CelebrityContester celebrityContester = (CelebrityContester) quizGameGUI.player;
            celebrityContester.donate();
        }

        quizGameGUI.frame.dispose();
    }
}
