package pdc_assignment;

import model.QuestionDBManager;
import model.Contester;
import model.ResultSaver;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestSaveNotCompletedContester 
{

    public TestSaveNotCompletedContester() 
    {
    }
    
    @BeforeClass
    public static void setUpClass()
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
    }
    
    @After
    public void tearDown()
    {
    }


    /**
     * This is to test the saveNotCompletedContester method.
     * @throws Exception if there is an error when testing.
     */
    @Test
    public void testSaveNotCompletedContester() throws Exception 
    {
        System.out.println("saveNotCompletedContester");

        Contester contester = new Contester("TESTNAME") 
        {
            @Override
            public void displayVictoryMessage() 
            {
            }
        };
        contester.setPrize(100);
        String comment = "TEST COMMENT";

        QuestionDBManager dbManager = new QuestionDBManager(); 
        ResultSaver resultSaver = new ResultSaver(dbManager);

        resultSaver.saveNotCompletedContester(contester, comment);

    }

    
}
