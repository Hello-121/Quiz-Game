package pdc_assignment;

import model.ResultChecker;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestGetTheContesterPrize 
{
    
    public TestGetTheContesterPrize()
    {
    }
    
    @BeforeClass
    public static void setUpClass() 
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
    }
    
    @After
    public void tearDown() 
    {
    }

    /**
     * This is to test the getTheContesterPrize method.
     * @throws Exception if there is an error when testing.
     */ 
    @Test
    public void testGetTheContesterPrize() throws Exception 
    {
        System.out.println("getTheContesterPrize");
        String contesterName = "TESTNAME";
        
        int expResult = 100; 
        int result = ResultChecker.getTheContesterPrize(contesterName);
        
        assertEquals(expResult, result);
    }
    
}
