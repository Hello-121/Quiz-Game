package pdc_assignment;

import java.util.ArrayList;
import java.util.List;

public class Chance 
{
    boolean hasUsedChance = false;

    public void chanceOf5050(Contester theContester, Question theQuestion) 
    {
        
        int answerPosition = theQuestion.getCanbeTrueAnswers().indexOf(theQuestion.getRightAnswer());

        List<Integer> displayedOptions = new ArrayList<>();
        displayedOptions.add(answerPosition);

        for (int i = 0; i < theQuestion.getCanbeTrueAnswers().size(); i++) 
        {
            if (i != answerPosition && displayedOptions.size() < 2) 
            {
                displayedOptions.add(i);
                break;
            }
        }
        
         hasUsedChance = true;
    }
}
