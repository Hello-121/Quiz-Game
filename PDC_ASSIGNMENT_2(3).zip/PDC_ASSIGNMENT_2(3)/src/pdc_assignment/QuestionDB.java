package pdc_assignment;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class QuestionDB 
{
    private Connection conn;
    private Statement statement;

    public QuestionDB(QuestionDBManager dbManager)     
    {
        conn = dbManager.getConnection();
        try 
        {
            statement = conn.createStatement();
        } 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
        }
    }
    
    public ResultSet getAllQuestions() 
    {
            try 
            {
                return statement.executeQuery("SELECT * FROM question");
            } 
            catch (SQLException ex) 
            {
                System.out.println(ex.getMessage());
                
                return null;
            }
    }
    

}
