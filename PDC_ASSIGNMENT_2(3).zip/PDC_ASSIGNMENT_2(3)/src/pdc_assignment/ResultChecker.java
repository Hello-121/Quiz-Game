package pdc_assignment;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ResultChecker 
{

    private static QuestionDBManager dbManager = new QuestionDBManager();

    public static boolean isTheContesterInResultsFile(String contesterName) throws IOException 
    {
        Connection conn = dbManager.getConnection();
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try 
        {
            String query = "SELECT * FROM result WHERE LOWER(name) = LOWER(?)";
            statement = conn.prepareStatement(query);
            statement.setString(1, contesterName);
            resultSet = statement.executeQuery();

            if (resultSet.next()) 
            {

                return true;
            }
        } 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            
        } 
        finally 
        {
            try 
            {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                
            } 
            catch (SQLException ex) 
            {
                System.out.println(ex.getMessage());
                
            }
        }
        
        return false;
    }

    
    public static int getTheContesterPrize(String contesterName) throws IOException 
    {
        Connection conn = dbManager.getConnection();
        Statement statement = null;
        ResultSet resultSet = null;
        
        int prize = 0;

        try 
        {
            statement = conn.createStatement();
            resultSet = statement.executeQuery("SELECT MAX(prize) AS max_prize FROM result WHERE name='" + contesterName + "'");

            if (resultSet.next()) 
            {
                prize = resultSet.getInt("max_prize");
                
            }
        } 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            
        } 
        finally 
        {
            try 
            {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                
            } 
            catch (SQLException ex) 
            {
                System.out.println(ex.getMessage());
                
            }
        }
        
        try 
        {
            if (conn != null) conn.close();
            
        } 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
            
        }

        return prize;
    }

}
