package pdc_assignment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TestDBFetch 
{
    private QuestionDBManager dbManager;

    public TestDBFetch(QuestionDBManager dbManager) 
    {
        this.dbManager = dbManager;
    }

    public void getPrizeByName(String name) 
    {
        String sql = "SELECT prize FROM result WHERE name = ?";
        Connection conn = this.dbManager.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try 
        {
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, name);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) 
            {
                int prize = resultSet.getInt("prize");
                System.out.println("Prize for " + name + ": " + prize);
            } 
            else 
            {
                System.out.println("No data found for name: " + name);
            }
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
        } 
        finally 
        {
        
            try 
            {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (conn != null) conn.close();
            } 
            catch (SQLException ex) 
            {
                ex.printStackTrace();
            }
        }
    }

    public static void main(String[] args) 
    {
        QuestionDBManager dbManager = new QuestionDBManager();
        TestDBFetch dbFetch = new TestDBFetch(dbManager);

 
        dbFetch.getPrizeByName("WOW");

        dbManager.closeConnections();
    }
}
