package pdc_assignment;

public class TestQuestionMain 
{
    public static void main(String[] args) 
    {
        QuestionDBManager dbManager = new QuestionDBManager();
        QuestionDB db = new QuestionDB(dbManager);

        dbManager.closeConnections();
    }
}
