package pdc_assignment;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Game 
{
    
    public static int stage;
            
    final static int[] prize = {100,200,300,500,1000,2000,4000,8000,16000,32000,64000,125000,250000,500000,1000000};
    
    private ResultSaver resultSaver;


    public void startTheGame(Contester newContester) throws IOException, InterruptedException 
    {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        QuestionDBManager dbManager = new QuestionDBManager();
        QuestionList questions = new QuestionList(dbManager);
        
        resultSaver = new ResultSaver(dbManager);


        int answerResult = -1;
        for (int i = 0; i < 15; i++) 
        {
            
            System.out.println("Stage " + (i + 1) + " of 15");
            questions.getAllQuestions().get(i).showQuestions(stage);

            int userInput = -1;
            String inputLine;

            while (true) 
            {
                if (i < 5) 
                {
                    long startTime = System.currentTimeMillis();
                    int timeLimit = 10 * 1000;

                    while (System.currentTimeMillis() - startTime < timeLimit && !reader.ready()) 
                    {
                        Thread.sleep(100);
                    }

                    if (reader.ready()) 
                    {
                        inputLine = reader.readLine();
                        if (inputLine.trim().equalsIgnoreCase("x")) 
                        {
                            System.out.println("Game stopped.");
                            System.exit(0);
                        }

                        try 
                        {
                            userInput = Integer.parseInt(inputLine) - 1;
                            if (userInput >= 0 && userInput <= 4) 
                            {
                                break;
                            } 
                            else 
                            {
                                System.out.println("Invalid input. Please enter a valid number (1, 2, 3, 4, or 5) or 'x' to quit.");
                            }
                        } catch (NumberFormatException e) 
                        {
                            System.out.println("Invalid input. Please enter a valid number (1, 2, 3, 4, or 5) or 'x' to quit.");
                        }
                    } 
                    else 
                    {
                        System.out.println("Time's up! Incorrect!");
                        break;
                    }
                } else 
                {
                    inputLine = reader.readLine();
                    if (inputLine.trim().equalsIgnoreCase("x")) {
                        System.out.println("Game stopped.");
                        System.exit(0);
                    }

                    try 
                    {
                        userInput = Integer.parseInt(inputLine) - 1;
                        if (userInput >= 0 && userInput <= 4) 
                        {
                            break;
                        } 
                        else 
                        {
                            System.out.println("Invalid input. Please enter a valid number.");
                        }
                    } catch (NumberFormatException e) 
                    {
                        System.out.println("Invalid input. Please enter a valid number.");
                    }
                }
            }

            answerResult = checkTheAnswer(userInput, newContester, questions.getAllQuestions().get(i), stage);

            if (answerResult == 1 || answerResult == 2) 
            {
                int num1;
                do 
                {
                    System.out.println("Enter <1> to continue?");
                    System.out.println("Enter <2> to walk Away with the prize of $" + newContester.getPrize() + "?");
                    System.out.print("-->");

                    try 
                    {
                        num1 = Integer.parseInt(reader.readLine());
                    } 
                    catch (NumberFormatException e) 
                    {
                        num1 = 0;
                    }

                    if (num1 < 1 || num1 > 2) 
                    {
                        System.out.println("Invalid input. Please enter a valid number (1 or 2).");
                    }
                } while (num1 < 1 || num1 > 2);

                if (num1 == 2)
                {
                    break;
                }
                stage++;
            } else 
            {

                break;
            }
        }

        if (answerResult != -1) 
        {
            newContester.displayVictoryMessage();
        }

            System.out.println("Congratulations! " + newContester.getName() + " just won the prize of $" + newContester.getPrize());


            if (stage < 15 || answerResult != 1) 
            {
                 System.out.println("You didn't complete all the questions.");
                 System.out.print("Please share your thoughts or comments: ");
                 String comment = reader.readLine();
                 resultSaver.saveNotCompletedContester(newContester, comment);

             } else if (stage == 15 && answerResult == 1) 
             {
                 System.out.println("Congratulations! You've completed all the questions!");
                 System.out.print("Please share your thoughts or comments: ");
                 String comment = reader.readLine();
                 resultSaver.saveCompletedContester(newContester, comment);
             }

            if (newContester instanceof CelebrityContester) 
            {
                CelebrityContester celebrityContester = (CelebrityContester) newContester;
                celebrityContester.donate();
                resultSaver.saveContesterResult(newContester);
            } 
            else 
            {
                resultSaver.saveContesterResult(newContester);
            }

            System.exit(0);
    }

    public static int checkTheAnswer(int userInput, Contester newContester, Question questions, int stage) throws InterruptedException 
    {
        System.out.print("\n");
        if (userInput == 4) 
        {
            newContester.getChance().useTheChance(newContester, questions, prize[stage], stage); 
            return 2; 
        } else if (userInput >= 0 && questions.getCanbeTrueAnswers().get(userInput).equals(questions.getRightAnswer())) 
        {
            newContester.setPrize(prize[stage]);
            System.out.println("Perfect! You just won the prize of $" + newContester.getPrize() + "\n");
            return 1; 
        } 
        else 
        {
            System.out.println("Unfortunately, it was not the right answer.\n");
            newContester.setPrize(0);
            return 0; 
        }
    }

    public void displayTheInstruction()
    {
        System.out.println("Answer 15 questions and win ONE MILLION DOLLARS!");
        System.out.println("Contesters will lose everything if doesn't get the right answer at any stage of the game.");
        System.out.println("Contesters can walk away with the prize at any stage of the game.");
        System.out.println("You need to select the answer in 10 sec for the first 5 questions.");
        System.out.println("Chance: Eliminates two incorrect answers, providing a 50/50 chance of selecting the correct answer!");
        System.out.println("There will be no option to use the chance for the first 5 questions.\n\n");
        System.out.println("After the game has started, you can enter 'x' to immediate stop the game.\n\n");
    }
    
}

