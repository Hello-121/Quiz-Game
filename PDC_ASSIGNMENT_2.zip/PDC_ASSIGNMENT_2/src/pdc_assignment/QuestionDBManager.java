package pdc_assignment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class QuestionDBManager 
{
    private static final String USER_NAME = ""; 
    private static final String PASSWORD = ""; 
    private static final String URL = "jdbc:derby:Question_EBD; create=true";  
    private Connection conn;

    public QuestionDBManager() 
    {
        establishConnection();
    }

    public Connection getConnection() 
    {
        return this.conn;
    }

    private void establishConnection() 
    {
        if (this.conn == null)
        {
            try 
            {
                conn = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
                System.out.println(URL + " Get Connected Successfully ....");
            }
            catch (SQLException ex) 
            {
                System.out.println(ex.getMessage());
            }
        }
    }

    public void closeConnections() 
    {
        if (conn != null) 
        {
            try 
            {
                conn.close();
            } 
            catch (SQLException ex) 
            {
                System.out.println(ex.getMessage());
            }
        }
    }
}
