package pdc_assignment;

public class nonCelebContester extends Contester
{

   public nonCelebContester(String name) 
   {
        super(name);
   }   

    @Override
    public void displayVictoryMessage() 
    {
        System.out.printf(getName() + " has contested as a Non-Celebrity! and ");
    }
}
