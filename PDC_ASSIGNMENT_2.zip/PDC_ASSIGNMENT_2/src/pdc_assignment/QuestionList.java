package pdc_assignment;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class QuestionList 
{
    private Map<String, Question> questionMap;

    public QuestionList(QuestionDBManager dbManager) throws IOException 
    {
        this.questionMap = new HashMap<>();
        this.getAllTheQuestion(dbManager);
    }

    public ArrayList<Question> getAllQuestions() 
    {
        return new ArrayList<>(this.questionMap.values());
    }

    public void addQuestion(Question question) 
    {
        this.questionMap.put(question.getQuestion(), question);
    }

    private void getAllTheQuestion(QuestionDBManager dbManager) 
    {
        QuestionDB questionDB = new QuestionDB(dbManager);

        try 
        {
            ResultSet rs = questionDB.getAllQuestions();

            while (rs.next()) 
            {
                ArrayList<String> answers = new ArrayList<>();
                
                for (int i = 2; i <= 5; i++) 
                {
                    answers.add(rs.getString(i));
                }

                Question aQuestion = new Question(rs.getString(1), rs.getString(6), answers);
                this.addQuestion(aQuestion);
            }
        } 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
        }
    }
}
