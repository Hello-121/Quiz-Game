package pdc_assignment;

import pdc_assignment.QuestionDBManager;
import pdc_assignment.Contester;
import pdc_assignment.ResultChecker;
import pdc_assignment.ResultSaver;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class TestCase3
{

    public TestCase3() 
    {
    }
    
    @BeforeClass
    public static void setUpClass() 
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
    }
    
    @After
    public void tearDown() 
    {
    }

    /**
     * This is to test the saveContesterResult method.
     * @throws Exception if there is an error when testing.
     */ 
    @Test
    public void testSaveContesterResult() throws Exception 
    {
        System.out.println("saveContesterResult");


        Contester contester = new Contester("TESTNAME") 
        {
            @Override
            public void displayVictoryMessage()
            {
            }
        };
        contester.setPrize(100);

        QuestionDBManager dbManager = new QuestionDBManager();  
        ResultSaver resultSaver = new ResultSaver(dbManager);

        resultSaver.saveContesterResult(contester);

        boolean isInserted = ResultChecker.isTheContesterInResultsFile(contester.getName());
        assertTrue(isInserted);

        int prize = ResultChecker.getTheContesterPrize(contester.getName());
        
        assertEquals(contester.getPrize(), prize);
    }
}
