package pdc_assignment;

import pdc_assignment.QuestionDBManager;
import pdc_assignment.Contester;
import pdc_assignment.ResultSaver;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestCase5 
{

    public TestCase5() 
    {
    }
    
    @BeforeClass
    public static void setUpClass()
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
    }
    
    @After
    public void tearDown()
    {
    }


    /**
     * This is to test the saveNotCompletedContester method.
     * @throws Exception if there is an error when testing.
     */
    @Test
    public void testSaveNotCompletedContester() throws Exception 
    {
        System.out.println("saveNotCompletedContester");

        Contester contester = new Contester("TESTNAME") 
        {
            @Override
            public void displayVictoryMessage() 
            {
            }
        };
        contester.setPrize(100);
        String comment = "TEST COMMENT";

        QuestionDBManager dbManager = new QuestionDBManager(); 
        ResultSaver resultSaver = new ResultSaver(dbManager);

        resultSaver.saveNotCompletedContester(contester, comment);

    }

    
}
