package pdc_assignment;

import java.util.ArrayList;

public class Question
{
    private String question;
    private String rightAnswer;
    private ArrayList<String> canBeTrueAnswers;
   
    /**
     * This is the Question's constructor.
     * @param question is the current question.
     * @param rightAnswer is the correct answer.
     * @param canBeTrueAnswers is the answers that can be right.
     */
    public Question(String question, String rightAnswer, ArrayList<String> canBeTrueAnswers)
    {
        this.setQuestion(question);
        this.setTheRightAnswer(rightAnswer);
        this.setCanBeTrueAnswers(canBeTrueAnswers);
        
    }

    /**
     * This is to get the answers.
     * @return the list of the answers
     */    
    public ArrayList<String> getCanbeTrueAnswers()
    {
        return this.canBeTrueAnswers;
    }
    
    /**
     * This is to get the question.
     * @return The question.
     */    
    public String getQuestion()
    {
        return this.question;
    }
    
    /** 
     * This is to set the question.
     * @param newQuestion is the new question.
     */    
    public void setQuestion(String newQuestion)
    {
        this.question = newQuestion;
    }
    
    /**
     * This is to get the right answer.
     * @return the right answer.
     */    
    public String getRightAnswer()
    {
        return this.rightAnswer;
    }

    /**
     * This is to set the right answer.
     * @param answer which will be the right answer
     */    
    public void setTheRightAnswer(String answer)
    {
        this.rightAnswer = answer;
    }

    /**
     * This is to set all the answers that can be true.
     * @param canBeTrueAnswers which is the answers that can be true.
     */    
    public void setCanBeTrueAnswers(ArrayList<String> canBeTrueAnswers)
    {
        this.canBeTrueAnswers = canBeTrueAnswers;
    }

    /**
     * This is to show the questions.
     * @param stage is the current stage of the stage.
     */    
    public void showQuestions(int stage) 
    {
        System.out.println("______________________________________");
        System.out.println(this.getQuestion());

        for (int x = 0; x < 4; x++)
            System.out.println("[" + (x + 1) + "]" + this.getCanbeTrueAnswers().get(x));

        if (stage >= 5) 
        {
            System.out.println("\nEnter[5] to see the Chance");
        }
        
        System.out.println("______________________________________");
    }
}