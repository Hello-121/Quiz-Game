package pdc_assignment;

import java.io.IOException;

public class MainGUI 
{
    /**
     * This is to start the Quiz Game.
     * @param args which is arguments.
     * @throws IOException if there is an input exception.
     */    
    public static void main(String[] args) throws IOException 
    {
        QuestionDBManager dbManager = new QuestionDBManager();

        QuizGameGUI gameGUI = new QuizGameGUI(dbManager);
        gameGUI.frame.setVisible(true);
        
    }
}




