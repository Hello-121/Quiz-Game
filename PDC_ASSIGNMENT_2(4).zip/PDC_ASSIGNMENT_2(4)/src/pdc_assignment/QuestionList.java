package pdc_assignment;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class QuestionList 
{
    private Map<String, Question> questionMap;
    private QuestionDBManager dbManager;  

    /**
     * This is a constructor for the QuestionList.
     * @param dbManager is the database manager.
     * @throws IOException if there is an error when reading the file.
     */    
    public QuestionList(QuestionDBManager dbManager) throws IOException 
    {
        this.dbManager = dbManager;  
        this.questionMap = new HashMap<>();
        this.getAllTheQuestion(dbManager);
    }

    /**
     * This is to get all the questions.
     * @return the array list 
     */    
    public QuestionDBManager getDbManager() 
    {
        return this.dbManager;
    }
    public ArrayList<Question> getAllQuestions() 
    {
        return new ArrayList<>(this.questionMap.values());
    }

    /**
     * This is to add the question to the question list.
     * @param question is the question that is to add. 
     */    
    public void addQuestion(Question question) 
    {
        this.questionMap.put(question.getQuestion(), question);
    }

    /**
     * This method is to get the questions for the file and add into the list.
     * @param filename is the name of the question file
     * @throws IOException if there is an error when reading the file.
     */    
    private void getAllTheQuestion(QuestionDBManager dbManager) 
    {
        QuestionDB questionDB = new QuestionDB(dbManager);

        try 
        {
            ResultSet rs = questionDB.getAllQuestions();

            while (rs.next()) 
            {
                ArrayList<String> answers = new ArrayList<>();
                
                for (int i = 2; i <= 5; i++) 
                {
                    answers.add(rs.getString(i));
                }

                Question aQuestion = new Question(rs.getString(1), rs.getString(6), answers);
                this.addQuestion(aQuestion);
            }
        } 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
        }
    }
}
