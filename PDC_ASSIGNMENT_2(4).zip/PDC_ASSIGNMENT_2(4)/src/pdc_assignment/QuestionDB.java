package pdc_assignment;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class QuestionDB 
{
    private Connection conn;
    private Statement statement;

    /**
     * This is a constructor for the QuestionDB.
     * @param dbManager which is the DB Manager.
     */    
    public QuestionDB(QuestionDBManager dbManager)     
    {
        conn = dbManager.getConnection();
        try 
        {
            statement = conn.createStatement();
        } 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
        }
    }
 
    /**
     * This is to fetch all the questions from the database.
     *
     * @return ResultSet which is all the questions or null if there are SQL exceptions.
     * 
     */    
    public ResultSet getAllQuestions() 
    {
            try 
            {
                return statement.executeQuery("SELECT * FROM question");
            } 
            catch (SQLException ex) 
            {
                System.out.println(ex.getMessage());
                
                return null;
            }
    }
    

}
