package pdc_assignment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class QuestionDBManager 
{
    private static final String USER_NAME = "pdc"; 
    private static final String PASSWORD = "pdc"; 
    private static final String URL = "jdbc:derby:Question_EBD; create=true";  
    private Connection conn;

    /**
     * This is a constructor for QuestionDBManager.
     */    
    public QuestionDBManager() 
    {
        establishConnection();
    }

    /**
     * This is to active the database connection.
     *
     * @return Connection which is the database connection
     */    
    public Connection getConnection() 
    {
        return this.conn;
    }

    /**
     * This is to connect to the database if the connection is null.
     */    
    private void establishConnection() 
    {
        if (this.conn == null)
        {
            try 
            {
                conn = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
                System.out.println(URL + " Get Connected Successfully ....");
            }
            catch (SQLException ex) 
            {
                System.out.println(ex.getMessage());
            }
        }
    }

    /**
     * This is to close the connection to the database.
     */    
    public void closeConnections() 
    {
        if (conn != null) 
        {
            try 
            {
                conn.close();
            } 
            catch (SQLException ex) 
            {
                System.out.println(ex.getMessage());
            }
        }
    }
}
