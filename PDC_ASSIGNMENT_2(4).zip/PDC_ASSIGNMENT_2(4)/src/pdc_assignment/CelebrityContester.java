package pdc_assignment;

import java.sql.SQLException;
import java.sql.Statement;

public class CelebrityContester extends Contester 
{
    private Chance chance;
    private QuestionDBManager dbManager;

   /**
    * This is a constructor for the CelebrityContester
    * @param name is the name of the contester
    */
    public CelebrityContester(String name, QuestionDBManager dbManager) 
    {
        super(name);
        this.chance = new Chance();
        this.dbManager = dbManager;
    }

   /**
    * This is to get the contester's chance.
    * @return the chance object.
    */
    @Override
    public Chance getChance() 
    {
        return this.chance;
    }
    
   /**
    * This method is to print the message of the donation. 
    */
    public void donate() 
    {
        System.out.println(getName() + " donated $" + getPrize());
        saveDonation();
    }

   /**
    * This method is to save that the contester's name and the donation.
    */
    private void saveDonation() 
    {
        try 
        {
            String query = "INSERT INTO CelebDonations (name, donation) VALUES ('" 
                            + getName() + "', " 
                            + getPrize() + ")";
            Statement statement = dbManager.getConnection().createStatement();
            statement.executeUpdate(query);
        } 
        catch (SQLException ex) 
        {
            System.err.println("Error while saving donation: " + ex.getMessage());
        }
    }
    
   /**
    * This method is to display the victory message.
    */    
    @Override
    public void displayVictoryMessage() 
    {
        System.out.printf(getName() + " has contested as a Celebrity! and ");
    }
    
}
