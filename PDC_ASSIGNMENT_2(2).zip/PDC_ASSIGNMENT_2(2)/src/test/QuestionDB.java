package test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class QuestionDB 
{
    private Connection conn;
    private Statement statement;

    public QuestionDB(QuestionDBManager dbManager) 
    {
        conn = dbManager.getConnection();
        
        try 
        {
            statement = conn.createStatement();
        } 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
        }
    }
    
    public ResultSet getAllQuestions() 
    {
            try
            {
                return statement.executeQuery("SELECT * FROM question");
                
            } 
            catch (SQLException ex) 
            {
                System.out.println(ex.getMessage());
                
                return null;
            }
    }
    
//    public void createAndPopulateTable() 
//    {
//        try 
//        {
//            statement.addBatch("CREATE TABLE question (question VARCHAR(255), option1 VARCHAR(255), option2 VARCHAR(255), option3 VARCHAR(255), option4 VARCHAR(255), correct VARCHAR(255))");
//            statement.addBatch("INSERT INTO question VALUES ('Which city is the capital of New Zealand?', 'Auckland', 'Hamilton', 'Wellington', 'Christchurch', 'Wellington')");
//            statement.addBatch("INSERT INTO question VALUES ('Which country is closest to New Zealand?', 'Fiji', 'Australia', 'Papua New Guinea', 'New Caledonia', 'New Caledonia')");
//            statement.addBatch("INSERT INTO question VALUES ('Which bird represents New Zealand?', 'Kiwi', 'Songbirds', 'Parrots', 'Owl', 'Kiwi')");
//            statement.addBatch("INSERT INTO question VALUES ('Which year was the first railway built in New Zealand?', '1983', '1992', '1876', '1862', '1862')");
//            statement.addBatch("INSERT INTO question VALUES ('How many islands does New Zealand have?', '600', '1200', '400', '100', '600')");
//            statement.addBatch("INSERT INTO question VALUES ('How far is Auckland from Wellington?', '631km', '321km', '100km', '490km', '631km')");
//            statement.addBatch("INSERT INTO question VALUES ('Which city has the highest population in New Zealand?', 'Wellington', 'Hamilton', 'Auckland', 'Christchurch', 'Auckland')");
//            statement.addBatch("INSERT INTO question VALUES ('What is the population of New Zealand?', '5million', '4million', '2million', '3million', '5million')");
//            statement.addBatch("INSERT INTO question VALUES ('Which city is the capital of Australia?', 'Sydney', 'Perth', 'Canberra', 'Melbourne', 'Canberra')");
//            statement.addBatch("INSERT INTO question VALUES ('How many states does Australia have?', '5', '4', '8', '6', '8')");
//            statement.addBatch("INSERT INTO question VALUES ('Which state is the biggest state in Australia?', 'Western Australia', 'Queensland', 'South Australia', 'New South Wales', 'New South Wales')");
//            statement.addBatch("INSERT INTO question VALUES ('How many islands does Australia have?', '8000', '4000', '1000', '12000', '8000')");
//            statement.addBatch("INSERT INTO question VALUES ('Which animal represents Australia?', 'Kangaroo', 'Tiger', 'Lion', 'Cheetah', 'Kangaroo')");
//            statement.addBatch("INSERT INTO question VALUES ('How many rugby world cups has New Zealand won?', '1', '2', '3', '4', '3')");
//            statement.addBatch("INSERT INTO question VALUES ('Where is the Sky Tower?', 'Auckland', 'Wellington', 'Hamilton', 'Christchurch', 'Auckland')");
//            statement.executeBatch();
//        } 
//        catch (SQLException ex) 
//        {
//            System.out.println(ex.getMessage());
//        }
//    }
}
