package test;

public class QuestionMain 
{
    public static void main(String[] args) 
    {
        QuestionDBManager dbManager = new QuestionDBManager();
        QuestionDB db = new QuestionDB(dbManager);

//        db.createAndPopulateTable();

        dbManager.closeConnections();
    }
}
