package pdc_assignment;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import pdc_assignment.CelebrityContester;
import pdc_assignment.Game;
import pdc_assignment.Contester;
import pdc_assignment.nonCelebContester;
import pdc_assignment.ResultChecker;
import java.util.concurrent.ExecutionException;

public class MillionaireGame 
{
    private static QuestionDBManager dbManager;

    public static void main(String[] args) throws FileNotFoundException, IOException, InterruptedException, ExecutionException 
    {
        dbManager = new QuestionDBManager();
        new QuestionDB(dbManager);

        System.out.println("System checked, Good to start.\n");
        try
        {
            new QuestionList(dbManager); 
            
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
        
        Game newGame = new Game();
        newGame.displayTheInstruction();

        Scanner scan = new Scanner(System.in);

        System.out.print("Name: ");
        String name = scan.nextLine().toUpperCase();

        if (ResultChecker.isTheContesterInResultsFile(name)) 
        {
            int prize = ResultChecker.getTheContesterPrize(name);
            
            System.out.println("You already contested and won $" + prize);

                    dbManager.closeConnections(); 

            System.exit(0);
        }

        System.out.print("Are you a celebrity? (yes/no): ");
        String isCelebrity = scan.nextLine().toLowerCase();
        Contester newContester;

        while (!isCelebrity.equals("yes") && !isCelebrity.equals("no")) 
        {
            System.out.println("Invalid input. Please enter 'yes' or 'no'.");
            System.out.print("Are you a celebrity? (yes/no): ");
            isCelebrity = scan.nextLine().toLowerCase();
            
        }

        if (isCelebrity.equals("yes")) 
        {
            newContester = new CelebrityContester(name, dbManager);
            
        }
        else 
        {
            newContester = new nonCelebContester(name);
        }

        boolean gameFinished = false;

        while (!gameFinished)
        {
            int gameSelect = getMenuSelection(scan);

            if (gameSelect == 1) 
            {
                newGame.startTheGame(newContester);
                
            } 
            else if (gameSelect == 2)
            {
                System.out.println("Farewell!");
                gameFinished = true;
                
            }
        }
        
         dbManager.closeConnections();
    }

    private static int getMenuSelection(Scanner scan) 
    {
        int gameSelect;

        do 
        {
            try 
            {
                System.out.println("\nEnter <1> to start the game");
                System.out.println("Enter <2> to quit the game");
                System.out.print("--> ");

                gameSelect = Integer.parseInt(scan.nextLine());

                if (gameSelect < 1 || gameSelect > 2) 
                {
                    System.out.println("Invalid input. Please enter a valid number (1 or 2).");
                    
                }
            } 
            catch (NumberFormatException e) 
            {
                System.out.println("Invalid input. Please enter a valid number (1 or 2).");
                gameSelect = 0;
                
            }
            
        } while (gameSelect < 1 || gameSelect > 2);

        return gameSelect;
    }
}
