package pdc_assignment;

import java.sql.SQLException;
import java.sql.Statement;

public class CelebrityContester extends Contester 
{
    private Chance chance;
    private QuestionDBManager dbManager;

    public CelebrityContester(String name, QuestionDBManager dbManager) 
    {
        super(name);
        this.chance = new Chance();
        this.dbManager = dbManager;
    }

    @Override
    public Chance getChance() 
    {
        return this.chance;
    }

    public void donate() 
    {
        System.out.println(getName() + " donated $" + getPrize());
        saveDonation();
    }

    private void saveDonation() 
    {
        try 
        {
            String query = "INSERT INTO CelebDonations (name, donation) VALUES ('" 
                            + getName() + "', " 
                            + getPrize() + ")";
            Statement statement = dbManager.getConnection().createStatement();
            statement.executeUpdate(query);
        } 
        catch (SQLException ex) 
        {
            System.err.println("Error while saving donation: " + ex.getMessage());
        }
    }
    
    @Override
    public void displayVictoryMessage() 
    {
        System.out.printf(getName() + " has contested as a Celebrity! and ");
    }
    
}
