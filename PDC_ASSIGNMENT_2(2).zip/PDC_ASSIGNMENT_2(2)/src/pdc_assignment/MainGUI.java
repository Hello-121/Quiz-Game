package pdc_assignment;

import java.io.IOException;

public class MainGUI 
{
    public static void main(String[] args) throws IOException 
    {
        QuestionDBManager dbManager = new QuestionDBManager();

        QuizGameGUI gameGUI = new QuizGameGUI(dbManager);
        gameGUI.frame.setVisible(true);
        
    }
}
