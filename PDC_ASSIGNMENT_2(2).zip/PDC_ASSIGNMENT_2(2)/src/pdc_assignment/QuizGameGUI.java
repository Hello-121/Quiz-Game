package pdc_assignment;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class QuizGameGUI 
{
    
    JFrame frame;
    private JButton startButton;
    private JButton[] answerButtons;
    private JTextField playerNameField;
    private JTextArea questionTextArea;
    private JCheckBox celebrityCheckBox;
    private JLabel feedbackLabel;
   
    private QuestionList questionList;
    private Question currentQuestion;
    private Contester player;
    private ResultSaver resultSaver;

    public static int stage;     
    final static int[] prize = {100,200,300,500,1000,2000,4000,8000,16000,32000,64000,125000,250000,500000,1000000};
    
    
    public QuizGameGUI(QuestionDBManager dbManager) throws IOException 
    {      
        questionList = new QuestionList(dbManager);
        resultSaver = new ResultSaver(dbManager);
        
        frame = new JFrame("Quiz Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(750, 650);

        playerNameField = new JTextField(25);
        celebrityCheckBox = new JCheckBox("I'm a celebrity");

        startButton = new JButton("Start Game");
        startButton.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                try 
                {
                    startGame();
                } catch (IOException ex) 
                {
                    Logger.getLogger(QuizGameGUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        questionTextArea = new JTextArea(10, 25);
        questionTextArea.setEditable(false);

        answerButtons = new JButton[4];
        for (int i = 0; i < 4; i++) 
        {
            answerButtons[i] = new JButton();
            final int index = i;
            answerButtons[i].addActionListener(new ActionListener() 
            {
                public void actionPerformed(ActionEvent e) 
                {
                    try 
                    {
                        handleAnswer(index);
                    } 
                    catch (IOException ex) 
                    {
                        Logger.getLogger(QuizGameGUI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
        }

        feedbackLabel = new JLabel();

        frame.setLayout(new BorderLayout());
        JPanel topPanel = new JPanel();
        topPanel.add(playerNameField);
        topPanel.add(celebrityCheckBox);
        topPanel.add(startButton);
        frame.add(topPanel, BorderLayout.NORTH);

        frame.add(new JScrollPane(questionTextArea), BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel();
        for (JButton button : answerButtons) 
        {
            bottomPanel.add(button);
        }
        bottomPanel.add(feedbackLabel);
        frame.add(bottomPanel, BorderLayout.SOUTH);
    }

    private void startGame() throws IOException 
    {
        String playerName = playerNameField.getText();
        if (ResultChecker.isTheContesterInResultsFile(playerName)) 
        {
            int prize = ResultChecker.getTheContesterPrize(playerName);

            JOptionPane.showMessageDialog(frame, "You've already contested and won $" + prize, "Already Played", JOptionPane.INFORMATION_MESSAGE);

            questionList.getDbManager().closeConnections();

            System.exit(0);
        } 
        else 
        {
            QuestionDBManager dbManager = new QuestionDBManager();
            if (celebrityCheckBox.isSelected()) 
            {
                player = new CelebrityContester(playerName, dbManager);
            } 
            else 
            {
                player = new nonCelebContester(playerName);
            }

            stage = 0;

            nextQuestion();
        }
    }


    private void handleAnswer(int buttonIndex) throws IOException 
    {
        String chosenAnswer = answerButtons[buttonIndex].getText();
        
        if (chosenAnswer.equals(currentQuestion.getRightAnswer())) 
        {
            player.setPrize(prize[stage]);
            stage++;

            int choice = JOptionPane.showConfirmDialog(frame,
                    "You got it right! Your prize is now $" + player.getPrize() + ". Do you want to walk away?", "Correct Answer",
                    JOptionPane.YES_NO_OPTION);

            if (choice == JOptionPane.YES_OPTION) 
            {
                String feedback = JOptionPane.showInputDialog(frame, "Please provide your feedback about the game:");
                resultSaver.saveNotCompletedContester(player, feedback);

                gameCompleted();
            } 
            else 
            {
                nextQuestion();
            }
        } 
        else
        {
            player.setPrize(0);
            feedbackLabel.setText("Sorry, that's incorrect. The correct answer was: " + currentQuestion.getRightAnswer());
            String feedback = JOptionPane.showInputDialog(frame, "Please provide your feedback about the game:");
            resultSaver.saveNotCompletedContester(player, feedback);

            gameCompleted();
        }
    }


    private void gameCompleted() throws IOException
    {
    //    String feedback = JOptionPane.showInputDialog(frame, "Please provide your feedback about the game:");
    //    player.setFeedback(feedback); 

        resultSaver.saveContesterResult(player);
            if (player instanceof CelebrityContester) 
            {
                CelebrityContester celebrityContester = (CelebrityContester) player;
                celebrityContester.donate();
 //               resultSaver.saveContesterResult(player);
//                frame.dispose();

            } 
            
        frame.dispose();
    }




    private void nextQuestion() throws IOException 
    {
        int currentQuestionIndex = questionList.getAllQuestions().indexOf(currentQuestion);
        
        if (currentQuestionIndex + 1 < questionList.getAllQuestions().size()) {
            currentQuestion = questionList.getAllQuestions().get(currentQuestionIndex + 1);
            questionTextArea.setText(currentQuestion.getQuestion());

            for (int i = 0; i < 4; i++) 
            {
                answerButtons[i].setText(currentQuestion.getCanbeTrueAnswers().get(i));
            }
        }
        else 
        {
            feedbackLabel.setText("Congratulations, you've answered all the questions!");
            String feedback = JOptionPane.showInputDialog(frame, "Please provide your feedback about the game:");
            resultSaver.saveCompletedContester(player, feedback);

            gameCompleted();
            frame.dispose();
        }
    }

}