package pdc_assignment;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Chance 
{
    private boolean hasUsedChance = false;

    public void chanceOf5050(Contester theContester, Question theQuestion) 
    {
        
        int answerPosition = theQuestion.getCanbeTrueAnswers().indexOf(theQuestion.getRightAnswer());
        System.out.println("______________________________________");
        System.out.println(theQuestion.getQuestion());
       

        List<Integer> displayedOptions = new ArrayList<>();
        displayedOptions.add(answerPosition);

        for (int i = 0; i < theQuestion.getCanbeTrueAnswers().size(); i++) 
        {
            if (i != answerPosition && displayedOptions.size() < 2) 
            {
                displayedOptions.add(i);
                break;
            }
        }

        for (int i = 0; i < displayedOptions.size(); i++) 
        {
            System.out.println("<" + (displayedOptions.get(i) + 1) + ">" + theQuestion.getCanbeTrueAnswers().get(displayedOptions.get(i)));
        }
        
         hasUsedChance = true;
        System.out.println("______________________________________");
    }

    public void useTheChance(Contester contester, Question aQuestion, int prize, int stage) throws InterruptedException 
    {
        Scanner scan = new Scanner(System.in);

        if (hasUsedChance) 
        {
            System.out.println("No more chances available!");
        } 
        else 
        {
            boolean validInput = false;

            while (!validInput) 
            {
                if (!hasUsedChance)
                {
                    System.out.println("Enter <1> to use the chance of 50/50");
                }

                System.out.println("Enter <2> to go back to the question");
                System.out.println("Please select the option");

                char selectChance = scan.next().charAt(0);
                selectChance = Character.toUpperCase(selectChance);

                switch (selectChance)
                {
                    case '1':
                        if (hasUsedChance) 
                        {
                            System.out.println("You already used the chance!");
                        } else {
                            chanceOf5050(contester, aQuestion);
                            validInput = true;
                        }
                        break;
                    case '2':
                        aQuestion.showQuestions(stage);
                        validInput = true;
                        break;
                    default:
                        System.out.println("Invalid input. Please try again.");
                }
            }
        }

        System.out.print("Please select the answer: ");

        int num = scan.nextInt();

        num--;
        System.out.print("\n");

        Game.checkTheAnswer(num, contester, aQuestion, Game.stage);
    }


}
