package pdc_assignment;

import java.util.ArrayList;

public class Question
{
    private String question;
    private String rightAnswer;
    private ArrayList<String> canBeTrueAnswers;

    public Question(String question, String rightAnswer, ArrayList<String> canBeTrueAnswers)
    {
        this.setQuestion(question);
        this.setTheRightAnswer(rightAnswer);
        this.setCanBeTrueAnswers(canBeTrueAnswers);
        
    }
    
    public ArrayList<String> getCanbeTrueAnswers()
    {
        return this.canBeTrueAnswers;
    }
    
    public String getQuestion()
    {
        return this.question;
    }
    
    public void setQuestion(String newQuestion)
    {
        this.question = newQuestion;
    }
    
    public String getRightAnswer()
    {
        return this.rightAnswer;
    }

    public void setTheRightAnswer(String answer)
    {
        this.rightAnswer = answer;
    }

    public void setCanBeTrueAnswers(ArrayList<String> canBeTrueAnswers)
    {
        this.canBeTrueAnswers = canBeTrueAnswers;
    }

    public void showQuestions(int stage) 
    {
        System.out.println("______________________________________");
        System.out.println(this.getQuestion());

        for (int x = 0; x < 4; x++)
            System.out.println("[" + (x + 1) + "]" + this.getCanbeTrueAnswers().get(x));

        if (stage >= 5) 
        {
            System.out.println("\nEnter[5] to see the Chance");
        }
        
        System.out.println("______________________________________");
    }
}