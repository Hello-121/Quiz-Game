package pdc_assignment;

public abstract class Contester 
{
    private String name;
    private int prize;
    private Chance chance;

    public Contester(String name) 
    {
        this.setName(name);
        this.setPrize(0);
        this.chance = new Chance();
    }

    public String getName() 
    {
        return this.name;
    }

    public void setName(String newName) 
    {
        this.name = newName.toUpperCase();
    }

    public int getPrize()
    {
        return this.prize;
    }

    public void setPrize(int prize) 
    {
        this.prize = prize;
    }
    
    public Chance getChance()
    {
        return this.chance;
    }
    
    public abstract void displayVictoryMessage();

    
}
