package pdc_assignment;

import model.ResultChecker;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestCase1
{
    
    public TestCase1() 
    {
    }
    
    @BeforeClass
    public static void setUpClass() 
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
    }
    
    @After
    public void tearDown() 
    {
    }

    /**
     * This is to test the isTheContesterInResultsFile method.
     * @throws Exception if there is an error when testing.
     */   
    @Test
    public void testIsTheContesterInResultsFile() throws Exception 
    {
        System.out.println("isTheContesterInResultsFile");
        String contesterName = "TESTNAME";
        
        boolean expResult = true; 
        boolean result = ResultChecker.isTheContesterInResultsFile(contesterName);
        
        assertEquals(expResult, result);
    }

}
