package model;

import model.QuestionDBManager;
import model.Contester;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Statement;

public class ResultSaver 
{
    private QuestionDBManager dbManager;

    
    public ResultSaver(QuestionDBManager dbManager) 
    {
        this.dbManager = dbManager;
    }
    
    /**
     * This method is save the result of the contester into the file.
     * @param contester is the object of the contester.
     * @throws IOException if there is an error when connecting to the database.
     */    
    public void saveContesterResult(Contester contester) throws IOException 
    {
        try 
        {
            String query = "INSERT INTO result (name, prize) VALUES ('" + contester.getName() + "', " + contester.getPrize() + ")";
            Statement statement = dbManager.getConnection().createStatement();
            statement.executeUpdate(query);
        } 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * This method is to save the contester's name and the comments who completed the game.
     * @param contester is the object of the contester.
     * @param comment is the comment of the contester.
     */
    public void saveCompletedContester(Contester contester, String comment) 
    {
        try 
        {
            String query = "INSERT INTO completed (name, message) VALUES ('" + contester.getName() + "', '" + comment + "')";
            Statement statement = dbManager.getConnection().createStatement();
            statement.executeUpdate(query);
        } 
        catch (SQLException ex) 
        {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * This method is to save the contester's name and the comment who did not complete the game.
     * @param contester is the object of the contester.
     * @param comment is the comment of the contester.
     */
    public void saveNotCompletedContester(Contester contester, String comment) 
    {
        try 
        {
            String query = "INSERT INTO NotCompleted (name, prize, comment) VALUES ('" 
                            + contester.getName() + "', " 
                            + contester.getPrize() + ", '" 
                            + comment + "')";
            Statement statement = dbManager.getConnection().createStatement();
            statement.executeUpdate(query);
        } 
        catch (SQLException ex)
        {
            System.out.println(ex.getMessage());
        }
    }

    
    
}
